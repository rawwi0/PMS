const ProjectDetailsCard = ({ project }) => {
  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold">{project?.name}</h1>

      <pre>
        {JSON.stringify(project, null, 2)}
      </pre>
    </div>
  );
};

export default ProjectDetailsCard;
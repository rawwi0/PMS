const ProjectDetails = () => {
  return (
    <div className="p-6 text-white">
      <h1 className="text-4xl font-bold">
        PROJECT DETAILS WORKING
      </h1>
    </div>
  );
};

export default ProjectDetails;